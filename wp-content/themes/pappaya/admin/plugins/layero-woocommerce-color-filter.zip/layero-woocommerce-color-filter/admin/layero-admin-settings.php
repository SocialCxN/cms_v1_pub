<?php
function layero_admin_actions() {
    add_options_page(
        'Layero-Colorfilter', 
        'Layero-Colorfilter', 
        'manage_options', 
        'Layero-Colorfilter', 
        'layero_color_filter_options'
    ); 
}
function layero_color_filter_options()
{
       ?>
	    <div class="wrap">
	    <h1><?php esc_html_e("Theme Panel","layero"); ?></h1>
	    <form method="post" action="options.php">
	        <?php
	            settings_fields("layero-filter");
	            do_settings_sections("layero-colorfilter-options");      
	            submit_button(); 
	        ?>          
	    </form>
		</div>
	<?php
}
add_action('admin_menu', 'layero_admin_actions'); 

function display_colortax_element()
{
	?>
   <select name="colorfilter_taxonomy">
  <?php 

  $attribute_taxonomies=layero_get_attribute_taxonomies();

 // $attribute_taxonomies['bomb']='michingan';
  //var_dump(get_option('colorfilter_taxonomy')); die;
  foreach ($attribute_taxonomies as $key => $value) { ?>

<option value="<?php echo $key; ?>" <?php selected(get_option('colorfilter_taxonomy'), $key); ?>><?php echo $value; ?></option>
<?php } ?>
   </select>
    <?php
}


function display_theme_panel_fields()
{
	add_settings_section("layero-filter", "All Settings", null, "layero-colorfilter-options");
	
	add_settings_field("colorfilter_taxonomy", esc_html__("Color Filter Taxonomy","layero"), "display_colortax_element", "layero-colorfilter-options", "layero-filter");


    register_setting("layero-filter", "colorfilter_taxonomy");

}

add_action("admin_init", "display_theme_panel_fields");

function layero_get_attribute_taxonomies(){

$attribute_array      = array();
$attribute_taxonomies = function_exists('wc_get_attribute_taxonomies')?wc_get_attribute_taxonomies():false;

if ( $attribute_taxonomies ) {
  foreach ( $attribute_taxonomies as $tax ) {
    if (function_exists('wc_attribute_taxonomy_name')){
      if ( taxonomy_exists( wc_attribute_taxonomy_name( $tax->attribute_name ) ) ) {
        $attribute_array[ wc_attribute_taxonomy_name( $tax->attribute_name ) ] = $tax->attribute_name;
      }
    }
  }
}
return $attribute_array;

}