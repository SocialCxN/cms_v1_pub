<?php

/**
 * Color filter hooks
 * Initiating the color filter hooks if the taxonomy is assigned.
 */

$color_filter_taxonomy=get_option('colorfilter_taxonomy');
if($color_filter_taxonomy!=null && (strlen($color_filter_taxonomy)>0) && ($color_filter_taxonomy!="none") ){
  add_action( $color_filter_taxonomy.'_add_form_fields', 'layero_add_color_field', 10, 2 );
  add_action( $color_filter_taxonomy.'_edit_form_fields', 'layero_edit_color_field', 10, 2 );
  add_action( 'admin_enqueue_scripts', 'layero_enqueue_admin_scripts' );
  add_action( 'edited_'.$color_filter_taxonomy, 'layero_save_color_taxonomy_custom_meta', 10, 2 );  
  add_action( 'create_'.$color_filter_taxonomy, 'layero_save_color_taxonomy_custom_meta', 10, 2 );
  add_filter('manage_edit-'.$color_filter_taxonomy.'_columns', 'layero_color_taxonomy_column_head');
  add_filter('manage_'.$color_filter_taxonomy.'_custom_column', 'layero_color_taxonomy_display_meta', 10, 3);
}



/**
 * layero Function - Add Color Field.
 * Adding Color select meta field to the color taxonomy.
 */
function layero_add_color_field() {

  ?>
  <div class="form-field">
    <label for="term_meta[color_term_meta]"><?php esc_html_e( 'Color', 'layero' ); ?></label>
    <input class="layero_color" type="text" name="term_meta[color_term_meta]" id="term_meta[color_term_meta]" value="">
    <p class="description"><?php esc_html_e( 'Select a color','layero' ); ?></p>
  </div>
  <?php
}



/**
 * layero Function - Edit Color Field.
 * Adding Color select meta field to the edit color taxonomy.
 */

function layero_edit_color_field($term) {

  $t_id = $term->term_id;
    // retrieve the existing value(s) for this meta field. This returns an array
  $term_meta = get_option( "taxonomy_$t_id" );   ?>
  <tr class="form-field">
    <th scope="row" valign="top"><label for="term_meta[color_term_meta]"><?php esc_html_e( 'Color', 'layero' ); ?></label></th>
    <td>
      <input class="layero_color" type="text" name="term_meta[color_term_meta]" id="term_meta[color_term_meta]" value="<?php echo esc_attr( $term_meta['color_term_meta'] ) ? esc_attr( $term_meta['color_term_meta'] ) : ''; ?>">
      <p class="description"><?php esc_html_e( 'Select a color','layero' ); ?></p>
    </td>
  </tr>
  <?php
}



/**
 * layero Function - Enqueue Admin Scripts.
 * Adding js to the WordPress admin.
 */


function layero_enqueue_admin_scripts( $hook_suffix ) {
    // first check that $hook_suffix is appropriate for your admin page
  if($hook_suffix=="edit-tags.php"){
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'adminscripts', get_template_directory_uri()."/js/adminscripts.js", array( 'wp-color-picker' ), false, true );
  }
}



/**
 * layero Function - Save Color taxonomy meta.
 * Saving the color taxonomy custom meta values.
 */

function layero_save_color_taxonomy_custom_meta( $term_id ) {
  if ( isset( $_POST['term_meta'] ) ) {
    $t_id = $term_id;
    $term_meta = get_option( "taxonomy_$t_id" );
    $cat_keys = array_keys( $_POST['term_meta'] );
    foreach ( $cat_keys as $key ) {
      if ( isset ( $_POST['term_meta'][$key] ) ) {
        $term_meta[$key] = $_POST['term_meta'][$key];
      }
    }
        // Save the option array.
    update_option( "taxonomy_$t_id", $term_meta );
  }
}  




/**
 * layero Function - Color taxonomy add column.
 * Adding the meta column to color taxonomy.
 */


function layero_color_taxonomy_column_head($defaults) {

  $defaults['color_code']  = esc_html__('Color Code','layero');
  return $defaults;
}


/**
 * layero Function - Display taxonomy meta.
 * Displaying the color taxonomy meta value column.
 */


function layero_color_taxonomy_display_meta($c, $column_name, $term_id) {

  if ($column_name == 'color_code') {       
   $t_id = $term_id;
    // retrieve the existing value(s) for this meta field. This returns an array
   $term_meta = get_option( "taxonomy_$t_id" );
   echo esc_html($term_meta['color_term_meta']);
 }
}