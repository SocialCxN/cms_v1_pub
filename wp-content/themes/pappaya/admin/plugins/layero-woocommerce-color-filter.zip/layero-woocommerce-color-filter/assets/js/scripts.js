jQuery(document).ready(function($){
    jQuery('.layero_color').wpColorPicker();
});