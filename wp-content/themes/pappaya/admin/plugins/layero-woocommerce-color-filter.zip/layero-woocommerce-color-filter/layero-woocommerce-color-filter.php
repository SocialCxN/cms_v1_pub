<?php
/**
 * @package Woocommerce_color_filter
 * @version 1.6
 */
/*
Plugin Name: Layero Woocommerce Color Filter
Plugin URI: http://layero.com
Description: Color filter plugin for Woocommerce.
Author: Linjo Joson
Version: 1.0
Text Domain: layero
*/

/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

	define( 'LAYERO_EXTENSION_DIR' , plugin_dir_path( __FILE__ ) );
	add_action( 'plugins_loaded', 'layero_load_plugin_textdomain' );

	function layero_load_plugin_textdomain() {
		load_plugin_textdomain( 'layero', FALSE, basename( dirname( __FILE__ ) ) . '/assets/languages/' );
	}
	add_action( 'widgets_init' , 'layero_register_widgets');

	function layero_register_widgets(){
		require_once LAYERO_EXTENSION_DIR . '/widget/widget-color-filter.php';
		register_widget('Layero_Woocommerce_Color_Filter');
	}

	require_once LAYERO_EXTENSION_DIR . '/admin/layero-admin-settings.php';
	require_once LAYERO_EXTENSION_DIR . '/admin/layero-color-filter-settings.php';
	global $pagenow;
	if(($pagenow=="edit-tags.php") || ($pagenow=="term.php") && $_GET['post_type']=="product"){
		add_action('admin_enqueue_scripts', 'layero_load_scripts');
	}
	add_action('wp_enqueue_scripts', 'layero_color_filter_css');

	function layero_load_scripts(){
		if( !wp_script_is( 'wp-color-picker') ){
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script('wp-color-picker',null,'jquery');
		}
		wp_enqueue_script( 'layero-scripts', plugin_dir_url(__FILE__) . '/assets/js/scripts.js', 'jquery' );
	}

	function layero_color_filter_css(){
		wp_enqueue_style( 'layero-color-css', plugin_dir_url(__FILE__) . '/assets/css/color-style.css' );
	}

}